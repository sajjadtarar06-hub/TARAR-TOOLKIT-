
document.addEventListener("DOMContentLoaded",()=>{
  const img=document.getElementById("secureImg");
  const fixedSrc="https://imgpx.com/en/dP9N4tN4kBrw.jpg";
  const border=document.querySelector(".border-rotate");

  // Gentle white glow pulse
  setInterval(()=>{
    border.style.filter=`drop-shadow(0 0 ${Math.random()*10+5}px rgba(255,255,255,0.7))`;
  },400);

  // Soft check (visual reload if altered)
  setInterval(()=>{
    if(img.src!==fixedSrc) img.src=fixedSrc;
  },1000);
});


/* ===== INLINE JAVASCRIPT ===== */


  // Optional: set your real links here
  document.querySelector('.youtube').href = "https://www.youtube.com/@DARK_LEGEND_333_JAVED";
  document.querySelector('.telegram').href = "https://t.me/DARK_LEGEND_333";
  document.querySelector('.whatsapp').href = "https://whatsapp.com/channel/0029VayXZVb3gvWiPQdEmT2b";


/* ===== INLINE JAVASCRIPT ===== */


let followedWhatsApp = localStorage.getItem("followedWhatsApp") === "true";
let followedYouTube = localStorage.getItem("followedYouTube") === "true";

// Update badge status at start
updateBadges();

// If both already followed, skip follow screen
if (followedWhatsApp && followedYouTube) {
  showTool();
}

// When WhatsApp button clicked
document.getElementById("whatsappFollowBtn").addEventListener("click", () => {
  followedWhatsApp = true;
  localStorage.setItem("followedWhatsApp", "true");
  updateBadges();
  checkUnlock();
});

// When YouTube button clicked
document.getElementById("youtubeSubscribeBtn").addEventListener("click", () => {
  followedYouTube = true;
  localStorage.setItem("followedYouTube", "true");
  updateBadges();
  checkUnlock();
});

// Update the badges visually
function updateBadges() {
  const whBadge = document.getElementById("whBadge");
  const ytBadge = document.getElementById("ytBadge");

  whBadge.textContent = followedWhatsApp ? "WhatsApp: Joined ✅" : "WhatsApp: Not Joined";
  ytBadge.textContent = followedYouTube ? "YouTube: Subscribed ✅" : "YouTube: Not Joined";

  whBadge.classList.toggle("off", !followedWhatsApp);
  ytBadge.classList.toggle("off", !followedYouTube);
}

// Unlock condition
function checkUnlock() {
  if (followedWhatsApp && followedYouTube) {
    document.getElementById("continueButton").classList.remove("hidden");

    // Auto-continue after short delay
    setTimeout(() => {
      showTool();
    }, 2000);
  }
}

// Show tool screen
function showTool() {
  document.getElementById("followState").style.display = "none";
  document.getElementById("toolState").style.display = "block";
        }
    // back to follow
    function showFollow() {
      document.getElementById('toolState').style.display = 'none';
      document.getElementById('followState').style.display = 'block';
    }
        function downloaddark_legend(dark_legendName, url) {
            // Add visual feedback
            const clickedElement = event.currentTarget;
            clickedElement.classList.add('downloading');
            
            // Show download notification
           // showDownloadNotification(`${dark_legendName} download started!`);
            
            // Open download link in new tab
            window.open(url, '_blank');
            
            // Remove visual feedback after 2 seconds
            setTimeout(() => {
                clickedElement.classList.remove('downloading');
            }, 2000);
        }

        function showDownloadNotification(message) {
            const notification = document.getElementById('downloadNotification');
            notification.textContent = message;
            notification.classList.add('show');
            
            // Hide notification after 3 seconds
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }

        // Add some interactive effects
        document.addEventListener('DOMContentLoaded', function() {
            // Add hover sound effect simulation
            const dark_legendOptions = document.querySelectorAll('.dark_legend-option');
            dark_legendOptions.forEach(option => {
                option.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px) scale(1.02)';
                });
                
                option.addEventListener('mouseleave', function() {
                    if (!this.classList.contains('downloading')) {
                        this.style.transform = 'translateY(0) scale(1)';
                    }
                });
            });
        });
    

/* ===== INLINE JAVASCRIPT ===== */


function showFunnyMessage(){
  document.getElementById("funnyPopup").classList.remove("hidden");
}
function closeFunnyPopup(){
  document.getElementById("funnyPopup").classList.add("hidden");
}
